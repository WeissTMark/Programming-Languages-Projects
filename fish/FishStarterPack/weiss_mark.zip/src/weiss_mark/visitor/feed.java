package weiss_mark.visitor;

import weiss_mark.*;

public class feed implements visitor {


    @Override
    public void visit(habitat h) {

    }

    @Override
    public void visit(fish f) {

    }

    @Override
    public void visit(food f) {

    }

    @Override
    public void visit(cell c) {

    }
}
